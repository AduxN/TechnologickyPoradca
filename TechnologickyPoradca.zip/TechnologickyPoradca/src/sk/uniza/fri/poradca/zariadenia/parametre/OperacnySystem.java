package sk.uniza.fri.poradca.zariadenia.parametre;

/**
 * 01-May-21 - 14:35
 * Enum s typmi podporovaných operačných systémov
 * @author Adam
 */
public enum OperacnySystem {
    ANDROID,
    IOS,
    WINDOWS,
    MAC_OS,
    INY_OS
}
